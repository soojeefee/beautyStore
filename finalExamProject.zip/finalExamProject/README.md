Submitted by: Soojee Fee (directory id: sfee)
Group Members: Soojee Fee (sfee)
App Description: Beauty Store where users can add items to their cart, remove items from their cart, and checkout any desired products
Youtube Link: https://youtu.be/vES9M18_YQc
API: IPify (https://api.ipify.org?format=json)
Contact Email: sfee@terpmail.umd.edu# beautyStore
